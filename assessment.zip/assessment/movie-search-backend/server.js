const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const cors = require('cors'); // Import the cors middleware

const app = express();
const PORT = process.env.PORT || 8080;

// Middleware
app.use(bodyParser.json());
app.use(cors()); // Use cors middleware

// Create a MySQL connection pool
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'manager',
  database: 'movies',
  connectionLimit: 10, // adjust based on your needs
});

// Route to save movie details to the database
app.post('/save', (req, res) => {
  const { Title, Year, Type, Poster } = req.body;

  // Ensure that required fields are present
  if (!Title || !Year || !Type || !Poster) {
    return res.status(400).json({ error: 'Incomplete data. Unable to save to favorites.' });
  }

  // Insert movie details into the 'favorites' table
  pool.execute(
    'INSERT INTO favorites (title, year, type, poster) VALUES (?, ?, ?, ?)',
    [Title, Year, Type, Poster],
    (error, results) => {
      if (error) {
        console.error('Error saving to favorites:', error);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      console.log('Movie saved to favorites:', results);
      res.status(200).json({ message: 'Movie saved to favorites' });
    }
  );
});

app.get('/get', (req, res) => {
    // Select all columns from the 'favorites' table
    pool.execute('SELECT * FROM favorites', (error, results) => {
      if (error) {
        console.error('Error fetching favorites:', error);
        return res.status(500).json({ error: 'Internal Server Error' });
      }
  
      console.log('Favorites fetched successfully:', results);
      res.status(200).json(results);
    });
  });

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
